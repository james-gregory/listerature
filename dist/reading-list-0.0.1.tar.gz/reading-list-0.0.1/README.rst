reading-list is a package for generating chronologically ordered reading lists using a Google Scholar API.
